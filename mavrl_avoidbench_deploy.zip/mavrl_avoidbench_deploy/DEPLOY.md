# Deploying the MAVRL + AvoidBench evaluation on the testing PC

This package builds a Docker image with AvoidBench (Unity + Gazebo + RotorS) and the MAVRL policy, then runs the benchmark and collects metrics.

```
mavrl_avoidbench_deploy/
├── DEPLOY.md          ← this file
├── run_benchmark.sh   ← runs the benchmark (smoke test or full run)
├── PROJECT_LOG.md     ← project history, interface spec, plan
└── mavrl/             ← Docker build context (Dockerfile + MAVRL code + checkpoints)
```

## 1. Requirements

| | Needed |
|---|---|
| OS | Linux with a desktop session (X11 or Wayland). Unity and Gazebo open windows. |
| GPU | NVIDIA, **GTX 9xx up to RTX 40xx**. RTX 50-series is not supported (the stereo-depth CUDA code is built for sm_52–86). |
| NVIDIA driver | ≥ 465 (CUDA 11.3). Check with `nvidia-smi`. |
| Disk | ~60 GB free (the image is ~28 GB, plus build cache). |
| RAM | ≥ 16 GB recommended. The build uses 4 parallel jobs. |
| Internet | During the build: it downloads ROS, CUDA, PyTorch, AvoidBench and the Unity scenes. Not needed for running. |

## 2. Install Docker and the NVIDIA container toolkit (once)
```bash
# Docker: https://docs.docker.com/engine/install/ubuntu/
sudo usermod -aG docker $USER        # then log out and back in

# NVIDIA container toolkit:
# https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker
```
Check that containers can see the GPU:
```bash
docker run --rm --gpus all nvidia/cuda:11.3.1-base-ubuntu20.04 nvidia-smi
```

## 3. Build the image (once, about 1 hour)
**Build it on the testing PC itself.** Don't copy an image built on another machine: AvoidBench compiles everything with `-march=native`, so an image built on one CPU can crash with `Illegal instruction` on another.
```bash
unzip mavrl_avoidbench_deploy.zip && cd mavrl_avoidbench_deploy
docker build -t mavrl-avoidbench mavrl/ 2>&1 | tee build.log
```
At the end, the build log should contain `[build] Failed: No packages failed.`

## 4. Check the image (1 minute)
```bash
docker run --rm --gpus all mavrl-avoidbench bash -c '
  cd /root/AvoidBench/src/mavrl && python3 -c "
import torch, flightgym, sys, mav_baselines
sys.modules[\"rpg_baselines_prev\"] = mav_baselines
from mav_baselines.torch.recurrent_ppo.policies import MultiInputLstmPolicy
print(\"cuda:\", torch.cuda.is_available())
ck = torch.load(\"saved/RecurrentPPO_1/Policy/iter_00640.pth\", map_location=\"cpu\")
p = MultiInputLstmPolicy(features_dim=64, **ck[\"data\"])
p.action_net = torch.nn.Sequential(p.action_net, torch.nn.Tanh())
print(p.load_state_dict(ck[\"state_dict\"], strict=False))"'
```
Expected output: `cuda: True` and `_IncompatibleKeys(missing_keys=[], unexpected_keys=[])`.

## 5. Smoke test (about 5 minutes)
```bash
chmod +x run_benchmark.sh
./run_benchmark.sh --maps 1 --trials 3
```
Unity and Gazebo windows open, and the drone flies 3 trials. Expected:
- After about 1–2 minutes, `results/<timestamp>/logs/3_policy.log` shows `target: ...`. That means the policy received a goal.
- `results/<timestamp>/metrics_out.txt` gets one line per trial, and the script ends with `all trials done`.

## 6. Full evaluation
```bash
./run_benchmark.sh                     # 30 maps x 30 trials, checkpoint iter 640 (several hours)
./run_benchmark.sh --iter 540          # the other shipped checkpoint
./run_benchmark.sh --fov 86            # camera FOV matched to MAVRL training (see below)
```
Each run gets its own folder `results/YYYY-MM-DD_HHMM/` with:
- `settings.txt`: the options used
- `metrics_out.txt`: the results
- `logs/`: AvoidBench, pilot and policy logs

Stop a run with `Ctrl-C`. The container and the X access are cleaned up automatically.

**Camera FOV.** The benchmark default is 100° (640×480). MAVRL was trained on a 70° square image, and its node crops the centre square, which gives about 84°. `--fov 86` makes the crop match 70°. Agree with the supervisors which setting to report. Running both is the safest choice.

## 7. Reading the results
`metrics_out.txt` has one line per trial, with space-separated columns:

| # | Column | Meaning |
|---|---|---|
| 1 | distance | straight-line start→goal distance [m] |
| 2 | traversable distance | shortest collision-free path length [m] |
| 3 | traversability | map difficulty (same for all trials on one map) |
| 4 | relative gap size | map difficulty (same for all trials on one map) |
| 5 | path excess factor | flown path vs. optimal path (lower is better). In our test it was 1.00 on trials that didn't reach the goal |
| 6 | average goal velocity | [m/s] |
| 7 | processing time | policy compute time per step [s] |
| 8 | collisions | number of collisions in the trial |
| 9 | energy cost | |
| 10 | relative end distance | distance left to the goal at the end, relative (0 = reached) |

Quick summary:
```bash
awk '{n++; c+=$8; s+=($8==0); v+=$6} END {printf "trials %d | collision-free %.1f%% | mean collisions %.2f | mean goal vel %.2f m/s\n", n, 100*s/n, c/n, v/n}' results/*/metrics_out.txt
```

## 8. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| No `target:` in `3_policy.log`, logs repeat `get new mission`, Unity at ~400% CPU | Unity is rendering on the CPU. `run_benchmark.sh` already sets the PRIME offload variables. On a laptop, check that the NVIDIA driver is in use (`nvidia-smi` lists `AvoidBench.x86_64` with type `G` while running). |
| `cannot open display` / `Authorization required` | Run from a desktop terminal (not SSH), with `DISPLAY` set. The script runs `xhost +SI:localuser:root` itself. |
| `Illegal instruction` | The image was built on a different CPU. Rebuild on this PC. |
| `could not select device driver "" with capabilities: [[gpu]]` | The NVIDIA container toolkit isn't set up. Repeat step 2. |
| CUDA error / `no kernel image is available` | The GPU is too new (RTX 50xx) for CUDA 11.3. |
| Empty `metrics_out.txt` while trials run | The results folder isn't mounted. Use `run_benchmark.sh`, which mounts it. |
| `ALSA lib ... error` in logs | Harmless: the container has no sound card. |
| `[RotorSBridge] voltage value not updated` | Harmless warning from the agilicious pilot. |

To run things by hand (for example, to watch topics), start a container with the `docker run` line in `run_benchmark.sh`, using `-it` and `bash` instead of the script body. Then open shells with `docker exec -it ab-run bash` and run:
```bash
roslaunch avoid_manage rotors_gazebo.launch
roslaunch mavrl flying_hummingbird.launch
roscd mavrl && python3 avoider_vel_cmd.py
```
The task settings (maps, trials, seed, camera) are in `$AVOIDBENCH_PATH/avoid_manage/params/task_outdoor.yaml`. The policy checkpoint is set in `/root/AvoidBench/src/mavrl/configs/control/config.yaml`.
