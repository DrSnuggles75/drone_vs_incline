# Project log: RL policy evaluation (MAVRL → AvoidBench → rai-spear simulation)

All times are local (CEST). Each entry is marked with the date and time it was done.
Add new entries at the bottom of the **Log** section, and tick items off in **Plan**.

---

## Log

### 2026-10-02 10:08 — Repository survey
Read through the three directories in `project_corse/`:

| Dir | Role | Stack |
|---|---|---|
| `mavrl/` | TU Delft MAVRL: depth-image RL obstacle avoidance (VAE → LSTM → recurrent PPO) | ROS1 Noetic, Python 3.8, torch 1.12, SB3 1.4, AvoidBench/Unity |
| `rai-spear-simulation/` | PX4 SITL + Gazebo Harmonic simulation, LIO, A* planner, GRID-FAST topometric mapping | ROS2 Humble, Gazebo, PX4 |
| `rai-spear-autonomy/` | Real drone deployment runbook (Holybro / Pixhawk 6C), RL exploration policy (GATv2, ICRA'26) | ROS2, RealSense D455, RPLidar, Vicon |

Issues noticed (not fixed):
- `mavrl/train_policy.py` uses `sys` and `mav_baselines` without importing them.
- `rai-spear-autonomy/src/exploration/src/explorer.py`: `self.logger.info` should be `self.get_logger()`, the save path is hardcoded to another user's home, and `get_goals` crashes when a diagonal move has no free intermediate cell.
- `rai-spear-simulation/colcon_ws/setup.bash` points at `gz/models`, but the models are in `data/models`.
- `px4_position_control.cpp` is empty, and `map.publisher.py` only calls `spin_once`.
- The top-level `Dockerfile.txt` (Isaac Gym) is unrelated to all three directories.

### 2026-10-02 11:00 — Can MAVRL run on the rai-spear sim as-is?
Conclusion: yes, with interface changes and no retraining. PPO retraining isn't feasible, because training is tied to AvoidBench's Unity environment (`flightgym`). If perception transfers badly, the authors' own fallback applies: fine-tune only the VAE and LSTM from sim rosbags (`fine_tune_*_from_rosbag.py`, `assemble_fine_tuned_policy.py`).

Checked in the shipped checkpoint (`ckpts/available_policy/iter_00640.pth`):
- **Input:** a 1-channel uint8 depth image (1×256×256) plus a 7-value state.
- **Output:** 4 values in [-1, 1].
- **Loading:** the checkpoint pickles `gym`/SB3 objects, so loading it needs those packages.

### 2026-10-08 15:49 — Supervisors: first evaluate MAVRL in AvoidBench, packaged in Docker
Research findings:
- AvoidBench (`tudelft/AvoidBench`, commit `b9afb97`) vendors agilicious and the RPG controllers. MAVRL's C++ links against `../agilicious`, so `mavrl` must live in `AvoidBench/src/`.
- `avoidlib` needs CUDA at build time (GPU stereo matching), so the base image must be a CUDA **devel** image with ROS Noetic on top.
- Open3D 0.9.0 is needed: AvoidBench headers include it.
- Several downloads are pinned to `master`/`main`: pybind11, yaml-cpp, gtest, benchmark. They need pinning to keep the build reproducible.
- **Everything is compiled with `-march=native`.** Build the image on the PC that will run it.
- The SGM CUDA code is compiled for sm_52/61/62/75/86 (GTX 9xx to RTX 40xx). RTX 50-series cards are not supported.
- The official image `hangyutud/noetic_avoidbench` is from 2022 and undocumented. I built from scratch instead.
- Metrics are written to `$AVOIDBENCH_PATH/avoidmetrics/data/metrics_out.txt`, one line per trial.

### 2026-10-08 ~15:55 — Wrote `mavrl/Dockerfile`
- Base `nvidia/cuda:11.3.1-devel-ubuntu20.04`, ROS Noetic desktop-full (repo added via `ros-apt-source`), Open3D 0.9.0 from source.
- System Python 3.8 with torch 1.12.1+cu113, SB3 1.4.0 and the rest of the MAVRL packages. One interpreter shared with rospy, no conda.
- AvoidBench cloned at `b9afb97`, with its floating dependency downloads pinned via `sed`.
- Unity standalone v0.0.3; the `UNITY_URL` build argument overrides it.
- MAVRL copied in, with checkpoints placed in `saved/RecurrentPPO_1/Policy/`.
- Then `rosdep`, `catkin build`, and the `flightgym` Python module.

### 2026-10-08 16:06 — Build attempt 1: failed at step 8 (`pip install -e`)
- **Cause:** `"pip<24.1"` was already satisfied by Ubuntu's pip 20.0, so pip was never upgraded. Meanwhile `tensorboard` → `google-auth 2.50` → `cryptography 47` broke the system `pyOpenSSL`, and with it the old pip.
- **Fix:** `pip==24.0` and `google-auth==2.29.0` (the newest version without the `cryptography` dependency).

### 2026-10-08 16:30 — Build attempt 2: failed at step 4 (pip resolver)
- **Cause:** the new pip enforces dependencies, and `stable-baselines3==1.4.0` requires `gym<0.20`. The old pip had silently ignored this.
- **Fix:** `gym==0.19.0`.

### 2026-10-08 16:43 — Build attempt 3: succeeded
- The image `mavrl-avoidbench` is 28.1 GB.
- `catkin build`: 53 packages, 0 failed, 12 with warnings.
- Smoke test inside the image: CUDA is visible (GTX 1650), and the checkpoint loads with **no missing or unexpected keys** and returns an action.

### 2026-10-08 17:11 — First end-to-end test (1 map × 3 trials): stuck
- Gazebo, the pilot and the policy started, but Unity rendered on the **CPU** (414% CPU, 0% GPU). Scene setup never finished, so no `/depth` or goal was published, and the mission restarted in a loop.
- **Cause:** a hybrid-graphics laptop (AMD iGPU drives the display, the GTX 1650 is PRIME offload only) running Wayland.
- **Fix:** add these to `docker run`:
  `-e __NV_PRIME_RENDER_OFFLOAD=1 -e __GLX_VENDOR_LIBRARY_NAME=nvidia -e __VK_LAYER_NV_optimus=NVIDIA_only`

### 2026-10-08 17:12–17:18 — Second end-to-end test: works
- Unity ran on the GPU, depth arrived at about 20 Hz, and the policy flew three trials:

| Trial | Avg goal vel. | Collisions | Path excess | Rel. end dist. | Processing time |
|---|---|---|---|---|---|
| 1 | 3.98 m/s | 2 | 1.00 | 0.25 | 0.030 s |
| 2 | 2.60 m/s | 0 | 0.04 | 0.00 | 0.008 s |
| 3 | 3.45 m/s | 2 | 1.00 | 0.22 | 0.009 s |

- **Caveats:** three trials on one map are too few to conclude anything. The benchmark camera was 100° FOV, while MAVRL was trained on 70° (see open questions).

`metrics_out.txt` columns: distance, traversable distance, traversability, relative gap size, path excess factor, avg goal velocity, processing time, collisions, energy cost, relative end distance.

### 2026-10-08 17:19 — Dockerfile updated after the test (not rebuilt since)
- The run command in the header now has the PRIME variables, uses `xhost +SI:localuser:root`, and lists the three commands to run.
- It now runs `mkdir -p $AVOIDBENCH_PATH/avoidmetrics/data`, because AvoidBench silently skips writing metrics if that folder is missing.

### 2026-10-08 17:11 / 17:27 — Custom terrain (hills, slopes): feasibility
- **AvoidBench can't do custom terrain.** The ground is baked into the prebuilt Unity scene, whose source isn't public, and its physics world (`simple.world`) is flat. Its YAML only controls the scene choice and random obstacles (density, size, area, seed).
- **Decision: run the terrain tests in Gazebo** (rai-spear sim), where the terrain is fully controllable and the drone really collides with it.
- **From the training code (`avoid_vision_envs.cpp`):**
  - Start height is always 3.0 m and goal height is 3–4 m, over flat ground.
  - The reward penalises `|z − goal_z|`.
  - Vertical acceleration is capped at ±1 m/s².
  - All obstacles were vertical (trees and cylinders).
  - The policy has no sense of its height above ground.
- **Prediction (to be tested):** on climbs it tries to go around or collides; on descents it holds altitude.

### 2026-10-08 17:48 — Decisions: goal modes A and B, x500 drone. Port spec written.
- **Mode A:** one goal above the far end of the terrain. This tests whether the policy climbs from the height difference alone (out of its training range).
- **Mode B:** a chain of goals every few metres at a fixed height above ground. This keeps height steps small, as in training, and tests depth-based avoidance on sloped surfaces.
- **Drone:** PX4 `x500` with a custom depth camera (see the port spec below).

### 2026-10-09 08:10 — Created this log

### 2026-10-22 08:34 — Deployment package for the testing PC
- Created `mavrl_avoidbench_deploy.zip` (42 MB) containing:
  - `DEPLOY.md`: requirements, setup, build, check, smoke test, full run, reading results, troubleshooting
  - `run_benchmark.sh`: a one-command run with `--maps`, `--trials`, `--fov` and `--iter`, giving one `results/<timestamp>/` folder per run
  - this log
  - `mavrl/`: the build context
- Added `mavrl/.dockerignore`, which keeps `.git`, `imgs/` (330 MB) and `__pycache__` out of the zip and the image.
- The zip contains no pre-built image, because of `-march=native`. It must be built on the testing PC, with internet access.

### 2026-10-22 08:49 — Zip tested: built from the unpacked copy
- The 08:34 zip was unpacked into a fresh folder and built from there. `catkin build`: 0 failed. Image size 27.5 GB.
- This also verifies the 2026-10-08 17:19 Dockerfile changes, which had not been built until now.

### 2026-10-22 08:52 — Zip tested: smoke run with `run_benchmark.sh --maps 1 --trials 3`
- All 3 trials ran in about 3 minutes, the policy received every goal, and the container and X access were cleaned up on exit.
- Trials 1–2 closely repeat the 2026-10-08 run (same seed, so same maps). Trial 3 differed: avg goal velocity 8.94 m/s vs 3.45, relative end distance 0.71 vs 0.22. **Runs are not exactly repeatable**, so report means over many trials.
- **Fixed:** result files were written as root. The script now gives them back to the user on exit, including on Ctrl-C. The fix was tested on the smoke-run results, and the zip was rebuilt.

---

## MAVRL interface spec (from training code — the port must reproduce this exactly)

Policy rate: **10 Hz** (`sim_dt = 0.1`). Below, everything is in standard ENU world coordinates with a FLU body frame. The training "RFU" world frame reduces to the normal ENU bearing.

| Input | Definition |
|---|---|
| depth | metres; NaN/inf → 12; `min(d, 12) / 12 · 255` → uint8, 256×256, 70° FOV |
| state[0] | `log(horizontal distance to goal + 1)` |
| state[1] | horizontal speed in the body frame |
| state[2] | bearing to goal, `atan2(dy, dx)` |
| state[3] | velocity direction relative to heading, `atan2(v_left, v_fwd)` |
| state[4] | `goal_z − z` |
| state[5] | vertical speed |
| state[6] | yaw (from +x) |

| Output | Definition |
|---|---|
| action[0:3] | body acceleration fwd/left/up, `a · [4, 4, 1]` m/s² |
| action[3] | yaw rate, `a · 0.6` rad/s |

- **Command to PX4:** `v_cmd = v_measured + R(yaw) · a_body · 0.1`, sent as a `TrajectorySetpoint` with velocity and yawspeed. Convert ENU→NED: swap x and y, negate z, negate the yaw rate.
- **Memory:** reset the LSTM state on every new goal.

---

## Plan (going forward)

### Phase 1 — AvoidBench evaluation on the testing PC
- [x] 1.0 Deployment zip with instructions and run script, tested on the dev laptop (2026-10-22)
- [ ] 1.1 Install Docker + `nvidia-container-toolkit` on the testing PC.
- [ ] 1.2 Build the image **on the testing PC** (`-march=native`): `docker build -t mavrl-avoidbench mavrl/` (~1 h, ~28 GB).
- [ ] 1.3 Agree the benchmark camera FOV with supervisors. `fov: 86.0` in `task_outdoor.yaml` makes the policy's square crop match the 70° it was trained on.
- [ ] 1.4 Full run: `task_outdoor.yaml` (30 maps × 30 trials), for `iter_00640` and `iter_00540`.
- [ ] 1.5 Optional: fix `test_ppo.py` (its loop `range(24, num_policy)` evaluates nothing with only 2 checkpoints) for a quicker Unity-only check.

### Phase 2 — Port MAVRL to the rai-spear Gazebo sim (x500)
- [ ] 2.1 **TorchScript export** (in the AvoidBench image): `(depth, state, h, c) → (action, h, c)`. Check it against the original policy on random inputs.
- [ ] 2.2 **`x500_mavrl` model:** x500 + depth camera, 256×256, `horizontal_fov` 1.2217, far clip ≥ 12 m, ≥ 10 Hz, mounted ~0.2 m forward / 0.3 m up. PX4's `x500_depth` (OAK-D, 640×480, 73°) doesn't match training as-is.
- [ ] 2.3 **Launch without a PX4 rebuild:** spawn the model in the world, then start PX4 with `PX4_SYS_AUTOSTART=4001 PX4_GZ_MODEL_NAME=x500_mavrl_0`.
- [ ] 2.4 **ROS2 bridges:** depth via `ros_gz_bridge` (32FC1); PX4 via the MicroXRCE agent. **The `px4_msgs` version must match PX4.**
- [ ] 2.5 **ROS2 policy node** (rclpy, 10 Hz) implementing the interface spec above.
- [ ] 2.6 **Mission runner:** arm, offboard mode, take off to 3 m, publish goals, end on goal/timeout/crash, then restart Gazebo + PX4 for each run.
- [ ] 2.7 **Validation:** fly to goals ahead/left/right/behind on flat ground (catches frame errors), then a flat world with trees as a baseline.

### Phase 3 — Terrain evaluation
- [ ] 3.1 **Terrain generator script:** ramps (tilted boxes) at 0/5/10/15/20/30°, hills (heightmaps) of 2/5/10 m, and the same terrains flown downhill.
- [ ] 3.2 **Goal modes:** A (single goal above the far end) and B (goal chain at fixed height above ground).
- [ ] 3.3 **Logging:** one CSV per run with success, terrain collisions (contact sensor), minimum height above ground (from the known terrain shape), time and path length.
- [ ] 3.4 **Sweep and report:** success and collision rate vs slope angle and hill height, for A and B, against the flat baseline.
- [ ] 3.5 Optional, if perception transfers badly: fine-tune the VAE and LSTM on Gazebo depth rosbags, reported separately from zero-shot.

---

## Open questions
- Which PX4 branch/commit is used for `px4_sitl_neural` (rai-spear-simulation README)? Needed to match `px4_msgs` (task 2.4).
- Which benchmark camera FOV did the MAVRL paper use in AvoidBench (task 1.3)?
- Does the fine-tuned variant count as "evaluating an existing policy", or zero-shot only (task 3.5)?

## Reference: running the AvoidBench evaluation
```bash
xhost +SI:localuser:root
docker run -it --rm --name ab --gpus all --net host \
  -e DISPLAY=$DISPLAY -e NVIDIA_DRIVER_CAPABILITIES=all -v /tmp/.X11-unix:/tmp/.X11-unix \
  -e __NV_PRIME_RENDER_OFFLOAD=1 -e __GLX_VENDOR_LIBRARY_NAME=nvidia -e __VK_LAYER_NV_optimus=NVIDIA_only \
  -v $PWD/results:/root/AvoidBench/src/avoidbench/avoidmetrics/data \
  mavrl-avoidbench
# then, each in its own shell (docker exec -it ab bash):
roslaunch avoid_manage rotors_gazebo.launch
roslaunch mavrl flying_hummingbird.launch
roscd mavrl && python3 avoider_vel_cmd.py
```
Results: `results/metrics_out.txt`. Task size and seed: `$AVOIDBENCH_PATH/avoid_manage/params/task_outdoor.yaml`. Policy checkpoint: `mavrl/configs/control/config.yaml` (`trial`, `iter`).
