#!/usr/bin/env bash
# Run the MAVRL policy through the AvoidBench benchmark in the mavrl-avoidbench image.
#
#   ./run_benchmark.sh                          # full run: 30 maps x 30 trials
#   ./run_benchmark.sh --maps 1 --trials 3      # quick smoke test (~5 min)
#   ./run_benchmark.sh --fov 86 --iter 540      # camera FOV (deg) / checkpoint
#
# Results go to results/<timestamp>/ (metrics_out.txt + logs/ + settings.txt).
set -euo pipefail

MAPS=30 TRIALS=30 FOV="" ITER=640 IMAGE=mavrl-avoidbench
while [ $# -gt 0 ]; do
  case "$1" in
    --maps) MAPS=$2; shift 2 ;;
    --trials) TRIALS=$2; shift 2 ;;
    --fov) FOV=$2; shift 2 ;;
    --iter) ITER=$2; shift 2 ;;
    --image) IMAGE=$2; shift 2 ;;
    *) echo "unknown option: $1"; exit 1 ;;
  esac
done

OUT="$(pwd)/results/$(date +%Y-%m-%d_%H%M)"
mkdir -p "$OUT/logs"
printf 'maps=%s trials=%s fov=%s iter=%s image=%s\n' "$MAPS" "$TRIALS" "${FOV:-default(100)}" "$ITER" "$IMAGE" | tee "$OUT/settings.txt"

# Let the container (runs as root) draw the Unity/Gazebo windows; revoked on exit.
xhost +SI:localuser:root >/dev/null
# On exit (also Ctrl-C): stop the container, give the root-written results back to you, revoke X access.
trap 'docker rm -f ab-run >/dev/null 2>&1
      docker run --rm -v "$OUT":/o "$IMAGE" chown -R "$(id -u):$(id -g)" /o >/dev/null 2>&1
      xhost -SI:localuser:root >/dev/null' EXIT

# The __NV/__GLX/__VK vars make Unity render on the NVIDIA GPU on hybrid-graphics laptops
# (harmless elsewhere). Without them Unity falls back to CPU and the benchmark hangs in scene setup.
docker run --rm --name ab-run --gpus all --net host \
  -e DISPLAY="$DISPLAY" -e NVIDIA_DRIVER_CAPABILITIES=all -v /tmp/.X11-unix:/tmp/.X11-unix \
  -e __NV_PRIME_RENDER_OFFLOAD=1 -e __GLX_VENDOR_LIBRARY_NAME=nvidia -e __VK_LAYER_NV_optimus=NVIDIA_only \
  -e MAPS="$MAPS" -e TRIALS="$TRIALS" -e FOV="$FOV" -e ITER="$ITER" \
  -v "$OUT":/root/AvoidBench/src/avoidbench/avoidmetrics/data \
  "$IMAGE" bash -c '
set -e
source /root/AvoidBench/devel/setup.bash
TASK=$AVOIDBENCH_PATH/avoid_manage/params/task_outdoor.yaml
sed -i "s/^flight_number:.*/flight_number: $MAPS/; s/^  trials:.*/  trials: $TRIALS/" $TASK
[ -n "$FOV" ] && sed -i "s/^  fov:.*/  fov: $FOV/" $TASK
sed -i "s/^  iter:.*/  iter: $ITER/" /root/AvoidBench/src/mavrl/configs/control/config.yaml
LOG=$AVOIDBENCH_PATH/avoidmetrics/data/logs
roslaunch avoid_manage rotors_gazebo.launch > $LOG/1_avoidbench.log 2>&1 &
sleep 25
roslaunch mavrl flying_hummingbird.launch > $LOG/2_pilot.log 2>&1 &
sleep 5
cd /root/AvoidBench/src/mavrl && python3 -u avoider_vel_cmd.py > $LOG/3_policy.log 2>&1 &
TOTAL=$((MAPS * TRIALS)); M=$AVOIDBENCH_PATH/avoidmetrics/data/metrics_out.txt
echo "running $TOTAL trials..."
DONE=0
while [ "$DONE" -lt "$TOTAL" ]; do
  sleep 10; N=$(cat $M 2>/dev/null | wc -l)
  [ "$N" != "$DONE" ] && echo "  $(date +%H:%M)  $N/$TOTAL trials done"; DONE=$N
done
echo "all trials done"
'
echo "Results: $OUT/metrics_out.txt"
